import { Route } from '@angular/router';

import { DefaultLayoutComponent } from './default-layout.component';

export const DEFAULT_ROUTE: Route = {
    path: '',
    component: DefaultLayoutComponent,
    data: {
        authorities: [],
        pageTitle: 'Welcome, Java Hipster!'
    }
};
