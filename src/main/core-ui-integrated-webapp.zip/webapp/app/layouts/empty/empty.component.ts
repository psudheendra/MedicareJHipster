import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-empty',
  templateUrl: './empty.component.html',
  styles: []
})
export class EmptyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
