import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'jhi-business-owner',
    templateUrl: './business-owner.component.html',
    styles: []
})
export class BusinessOwnerComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
